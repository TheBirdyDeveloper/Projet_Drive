/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* ====================================================================
 * prunsrv -- Service Runner.
 * Contributed by Mladen Turk <mturk@apache.org>
 * 05 Aug 2003
 * ====================================================================
 */

/* Force the JNI vprintf functions */
#define _DEBUG_JNI  1
#include "apxwin.h"
#include "prunsrv.h"

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <fcntl.h>
#include <io.h>         /* _open_osfhandle */

#ifndef  MIN
#define  MIN(a,b)    (((a)<(b)) ? (a) : (b))
#endif

#define STDIN_FILENO  0
#define STDOUT_FILENO 1
#define STDERR_FILENO 2
#define ONE_MINUTE    (60 * 1000)

#ifdef _WIN64
#define KREG_WOW6432  KEY_WOW64_32KEY
#define PRG_BITS      64
#else
#define KREG_WOW6432  0
#define PRG_BITS      32
#endif

typedef struct APX_STDWRAP {
    LPCWSTR szLogPath;
    LPCWSTR szStdOutFilename;
    LPCWSTR szStdErrFilename;
    FILE   *fpStdOutFile;
    FILE   *fpStdErrFile;
} APX_STDWRAP;

/* Use static variables instead of #defines */
static LPCWSTR  PRSRV_AUTO        = L"auto";
static LPCWSTR  PRSRV_JAVA        = L"java";
static LPCWSTR  PRSRV_JVM         = L"jvm";
static LPCWSTR  PRSRV_JDK         = L"jdk";
static LPCWSTR  PRSRV_JRE         = L"jre";
static LPCWSTR  PRSRV_MANUAL      = L"manual";
static LPCWSTR  PRSRV_JBIN        = L"\\bin\\java.exe";
static LPCWSTR  PRSRV_PBIN        = L"\\bin";
static LPCWSTR  PRSRV_SIGNAL      = L"SIGNAL";
static LPCWSTR  STYPE_INTERACTIVE = L"interactive";

static LPWSTR       _service_name = NULL;
/* Allowed procrun commands */
static LPCWSTR _commands[] = {
    L"TS",      /* 1 Run Service as console application (default)*/
    L"RS",      /* 2 Run Service */
    L"ES",      /* 3 Execute start */
    L"SS",      /* 4 Stop Service */
    L"US",      /* 5 Update Service parameters */
    L"IS",      /* 6 Install Service */
    L"DS",      /* 7 Delete Service */
    L"?",       /* 8 Help */
    L"VS",      /* 9 Version */
    NULL
};

static LPCWSTR _altcmds[] = {
    L"run",         /* 1 Run Service as console application (default)*/
    L"service",     /* 2 Run Service */
    L"start",       /* 3 Start Service */
    L"stop",        /* 4 Stop Service */
    L"update",      /* 5 Update Service parameters */
    L"install",     /* 6 Install Service */
    L"delete",      /* 7 Delete Service */
    L"help",        /* 8 Help */
    L"version",     /* 9 Version */
    NULL
};

/* Allowed procrun parameters */
static APXCMDLINEOPT _options[] = {

/* 0  */    { L"Description",       L"Description",     NULL,           APXCMDOPT_STR | APXCMDOPT_SRV, NULL, 0},
/* 1  */    { L"DisplayName",       L"DisplayName",     NULL,           APXCMDOPT_STR | APXCMDOPT_SRV, NULL, 0},
/* 2  */    { L"Install",           L"ImagePath",       NULL,           APXCMDOPT_STE | APXCMDOPT_SRV, NULL, 0},
/* 3  */    { L"ServiceUser",       L"ServiceUser",     NULL,           APXCMDOPT_STR | APXCMDOPT_SRV, NULL, 0},
/* 4  */    { L"ServicePassword",   L"ServicePassword", NULL,           APXCMDOPT_STR | APXCMDOPT_SRV, NULL, 0},
/* 5  */    { L"Startup",           L"Startup",         NULL,           APXCMDOPT_STR | APXCMDOPT_SRV, NULL, 0},
/* 6  */    { L"Type",              L"Type",            NULL,           APXCMDOPT_STR | APXCMDOPT_SRV, NULL, 0},

/* 7  */    { L"DependsOn",         L"DependsOn",       NULL,           APXCMDOPT_MSZ | APXCMDOPT_REG, NULL, 0},
/* 8  */    { L"Environment",       L"Environment",     NULL,           APXCMDOPT_MSZ | APXCMDOPT_REG, NULL, 0},
/* 9  */    { L"User",              L"User",            NULL,           APXCMDOPT_STR | APXCMDOPT_REG, NULL, 0},
/* 10 */    { L"Password",          L"Password",        NULL,           APXCMDOPT_BIN | APXCMDOPT_REG, NULL, 0},
/* 11 */    { L"LibraryPath",       L"LibraryPath",     NULL,           APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},

/* 12 */    { L"JavaHome",          L"JavaHome",        L"Java",        APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},
/* 13 */    { L"Jvm",               L"Jvm",             L"Java",        APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},
/* 14 */    { L"JvmOptions",        L"Options",         L"Java",        APXCMDOPT_MSZ | APXCMDOPT_REG, NULL, 0},
/* 15 */    { L"Classpath",         L"Classpath",       L"Java",        APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},
/* 16 */    { L"JvmMs",             L"JvmMs",           L"Java",        APXCMDOPT_INT | APXCMDOPT_REG, NULL, 0},
/* 17 */    { L"JvmMx",             L"JvmMx",           L"Java",        APXCMDOPT_INT | APXCMDOPT_REG, NULL, 0},
/* 19 */    { L"JvmSs",             L"JvmSs",           L"Java",        APXCMDOPT_INT | APXCMDOPT_REG, NULL, 0},

/* 19 */    { L"StopImage",         L"Image",           L"Stop",        APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},
/* 20 */    { L"StopPath",          L"WorkingPath",     L"Stop",        APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},
/* 21 */    { L"StopClass",         L"Class",           L"Stop",        APXCMDOPT_STR | APXCMDOPT_REG, NULL, 0},
/* 22 */    { L"StopParams",        L"Params",          L"Stop",        APXCMDOPT_MSZ | APXCMDOPT_REG, NULL, 0},
/* 23 */    { L"StopMethod",        L"Method",          L"Stop",        APXCMDOPT_STR | APXCMDOPT_REG, NULL, 0},
/* 24 */    { L"StopMode",          L"Mode",            L"Stop",        APXCMDOPT_STR | APXCMDOPT_REG, NULL, 0},
/* 25 */    { L"StopTimeout",       L"Timeout",         L"Stop",        APXCMDOPT_INT | APXCMDOPT_REG, NULL, 0},

/* 26 */    { L"StartImage",        L"Image",           L"Start",       APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},
/* 27 */    { L"StartPath",         L"WorkingPath",     L"Start",       APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},
/* 28 */    { L"StartClass",        L"Class",           L"Start",       APXCMDOPT_STR | APXCMDOPT_REG, NULL, 0},
/* 29 */    { L"StartParams",       L"Params",          L"Start",       APXCMDOPT_MSZ | APXCMDOPT_REG, NULL, 0},
/* 30 */    { L"StartMethod",       L"Method",          L"Start",       APXCMDOPT_STR | APXCMDOPT_REG, NULL, 0},
/* 31 */    { L"StartMode",         L"Mode",            L"Start",       APXCMDOPT_STR | APXCMDOPT_REG, NULL, 0},

/* 32 */    { L"LogPath",           L"Path",            L"Log",         APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},
/* 33 */    { L"LogPrefix",         L"Prefix",          L"Log",         APXCMDOPT_STR | APXCMDOPT_REG, NULL, 0},
/* 34 */    { L"LogLevel",          L"Level",           L"Log",         APXCMDOPT_STR | APXCMDOPT_REG, NULL, 0},
/* 35 */    { L"StdError",          L"StdError",        L"Log",         APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},
/* 36 */    { L"StdOutput",         L"StdOutput",       L"Log",         APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},
/* 37 */    { L"LogJniMessages",    L"LogJniMessages",  L"Log",         APXCMDOPT_INT | APXCMDOPT_REG, NULL, 1},
/* 38 */    { L"PidFile",           L"PidFile",         L"Log",         APXCMDOPT_STR | APXCMDOPT_REG, NULL, 0},
/* 39 */    { L"Rotate",            L"Rotate",          L"Log",         APXCMDOPT_INT | APXCMDOPT_REG, NULL, 0},
            /* NULL terminate the array */
            { NULL }
};

#define GET_OPT_V(x)  _options[x].szValue
#define GET_OPT_I(x)  _options[x].dwValue
#define GET_OPT_T(x)  _options[x].dwType

#define ST_DESCRIPTION      GET_OPT_T(0)
#define ST_DISPLAYNAME      GET_OPT_T(1)
#define ST_INSTALL          GET_OPT_T(2)
#define ST_SUSER            GET_OPT_T(3)
#define ST_SPASSWORD        GET_OPT_T(4)
#define ST_STARTUP          GET_OPT_T(5)
#define ST_TYPE             GET_OPT_T(6)

#define SO_DESCRIPTION      GET_OPT_V(0)
#define SO_DISPLAYNAME      GET_OPT_V(1)
#define SO_INSTALL          GET_OPT_V(2)
#define SO_SUSER            GET_OPT_V(3)
#define SO_SPASSWORD        GET_OPT_V(4)
#define SO_STARTUP          GET_OPT_V(5)
#define SO_TYPE             GET_OPT_V(6)

#define SO_DEPENDSON        GET_OPT_V(7)
#define SO_ENVIRONMENT      GET_OPT_V(8)

#define SO_USER             GET_OPT_V(9)
#define SO_PASSWORD         GET_OPT_V(10)
#define SO_LIBPATH          GET_OPT_V(11)

#define SO_JAVAHOME         GET_OPT_V(12)
#define SO_JVM              GET_OPT_V(13)
#define SO_JVMOPTIONS       GET_OPT_V(14)
#define SO_CLASSPATH        GET_OPT_V(15)
#define SO_JVMMS            GET_OPT_I(16)
#define SO_JVMMX            GET_OPT_I(17)
#define SO_JVMSS            GET_OPT_I(18)

#define SO_STOPIMAGE        GET_OPT_V(19)
#define SO_STOPPATH         GET_OPT_V(20)
#define SO_STOPCLASS        GET_OPT_V(21)
#define SO_STOPPARAMS       GET_OPT_V(22)
#define SO_STOPMETHOD       GET_OPT_V(23)
#define SO_STOPMODE         GET_OPT_V(24)
#define SO_STOPTIMEOUT      GET_OPT_I(25)

#define SO_STARTIMAGE       GET_OPT_V(26)
#define SO_STARTPATH        GET_OPT_V(27)
#define SO_STARTCLASS       GET_OPT_V(28)
#define SO_STARTPARAMS      GET_OPT_V(29)
#define SO_STARTMETHOD      GET_OPT_V(30)
#define SO_STARTMODE        GET_OPT_V(31)

#define SO_LOGPATH          GET_OPT_V(32)
#define SO_LOGPREFIX        GET_OPT_V(33)
#define SO_LOGLEVEL         GET_OPT_V(34)

#define SO_STDERROR         GET_OPT_V(35)
#define SO_STDOUTPUT        GET_OPT_V(36)
#define SO_JNIVFPRINTF      GET_OPT_I(37)
#define SO_PIDFILE          GET_OPT_V(38)
#define SO_LOGROTATE        GET_OPT_I(39)

static SERVICE_STATUS        _service_status;
static SERVICE_STATUS_HANDLE _service_status_handle = NULL;
/* Set if launched by SCM   */
static BOOL                  _service_mode = FALSE;
/* JVM used as worker       */
static BOOL                  _jni_startup  = FALSE;
/* JVM used for shutdown    */
static BOOL                  _jni_shutdown = FALSE;
/* Java used as worker       */
static BOOL                  _java_startup  = FALSE;
/* Java used for shutdown    */
static BOOL                  _java_shutdown = FALSE;
/* Global variables and objects */
static APXHANDLE    gPool;
static APXHANDLE    gWorker;
static APX_STDWRAP  gStdwrap;           /* stdio/stderr redirection */
static int          gExitval;
static LPWSTR       gStartPath;

static LPWSTR   _jni_jvmpath              = NULL;   /* Path to jvm dll */
static LPSTR    _jni_jvmoptions           = NULL;   /* Path to jvm options */

static LPSTR    _jni_classpath            = NULL;
static LPCWSTR  _jni_rparam               = NULL;    /* Startup  arguments */
static LPCWSTR  _jni_sparam               = NULL;    /* Shutdown arguments */
static LPSTR    _jni_rmethod              = NULL;    /* Startup  method */
static LPSTR    _jni_smethod              = NULL;    /* Shutdown method */
static LPSTR    _jni_rclass               = NULL;    /* Startup  class */
static LPSTR    _jni_sclass               = NULL;    /* Shutdown class */
static HANDLE gShutdownEvent = NULL;
static HANDLE gSignalEvent   = NULL;
static HANDLE gSignalThread  = NULL;
static HANDLE gPidfileHandle = NULL;
static LPWSTR gPidfileName   = NULL;
static BOOL   gSignalValid   = TRUE;
static APXJAVA_THREADARGS gRargs;
static APXJAVA_THREADARGS gSargs;

DWORD WINAPI eventThread(LPVOID lpParam)
{
    DWORD dwRotateCnt = SO_LOGROTATE;

    for (;;) {
        DWORD dw = WaitForSingleObject(gSignalEvent, 1000);
        if (dw == WAIT_TIMEOUT) {
            /* Do process maintenance */
            if (SO_LOGROTATE != 0 && --dwRotateCnt == 0) {
                /* Perform log rotation. */

                 dwRotateCnt = SO_LOGROTATE;
            }
            continue;
        }
        if (dw == WAIT_OBJECT_0 && gSignalValid) {
            if (!GenerateConsoleCtrlEvent(CTRL_BREAK_EVENT, 0)) {
                /* Invoke Thread dump */
                if (gWorker && _jni_startup)
                    apxJavaDumpAllStacks(gWorker);
            }
            ResetEvent(gSignalEvent);
            continue;
        }
        break;
    }
    ExitThread(0);
    return 0;
}

/* redirect console stdout/stderr to files
 * so that java messages can get logged
 * If stderrfile is not specified it will
 * go to stdoutfile.
 */
static BOOL redirectStdStreams(APX_STDWRAP *lpWrapper, LPAPXCMDLINE lpCmdline)
{
    BOOL aErr = FALSE;
    BOOL aOut = FALSE;

    /* Allocate console if we have none
     */
    if (GetConsoleWindow() == NULL) {
        HWND hc;
        AllocConsole();
        if ((hc = GetConsoleWindow()) != NULL)
            ShowWindow(hc, SW_HIDE);
    }
    /* redirect to file or console */
    if (lpWrapper->szStdOutFilename) {
        if (lstrcmpiW(lpWrapper->szStdOutFilename, PRSRV_AUTO) == 0) {
            WCHAR lsn[1024];
            aOut = TRUE;
            lstrlcpyW(lsn, 1020, lpCmdline->szApplication);
            lstrlcatW(lsn, 1020, L"-stdout");
            lstrlocaseW(lsn);
            lpWrapper->szStdOutFilename = apxLogFile(gPool,
                                                     lpWrapper->szLogPath,
                                                     lsn,
                                                     NULL, TRUE,
                                                     SO_LOGROTATE);
        }
        /* Delete the file if not in append mode
         * XXX: See if we can use the params instead of that.
         */
        if (!aOut)
            DeleteFileW(lpWrapper->szStdOutFilename);
        if ((lpWrapper->fpStdOutFile = _wfopen(lpWrapper->szStdOutFilename,
                                               L"a"))) {
            _dup2(_fileno(lpWrapper->fpStdOutFile), 1);
            *stdout = *lpWrapper->fpStdOutFile;
            setvbuf(stdout, NULL, _IONBF, 0);
        }
        else
            lpWrapper->szStdOutFilename = NULL;
    }
    if (lpWrapper->szStdErrFilename) {
        if (lstrcmpiW(lpWrapper->szStdErrFilename, PRSRV_AUTO) == 0) {
            WCHAR lsn[1024];
            aErr = TRUE;
            lstrlcpyW(lsn, 1020, lpCmdline->szApplication);
            lstrlcatW(lsn, 1020, L"-stderr");
            lstrlocaseW(lsn);
            lpWrapper->szStdErrFilename = apxLogFile(gPool,
                                                     lpWrapper->szLogPath,
                                                     lsn,
                                                     NULL, TRUE,
                                                     SO_LOGROTATE);
        }
        if (!aErr)
            DeleteFileW(lpWrapper->szStdErrFilename);
        if ((lpWrapper->fpStdErrFile = _wfopen(lpWrapper->szStdErrFilename,
                                              L"a"))) {
            _dup2(_fileno(lpWrapper->fpStdErrFile), 2);
            *stderr = *lpWrapper->fpStdErrFile;
            setvbuf(stderr, NULL, _IONBF, 0);
        }
        else
            lpWrapper->szStdOutFilename = NULL;
    }
    else if (lpWrapper->fpStdOutFile) {
        _dup2(_fileno(lpWrapper->fpStdOutFile), 2);
        *stderr = *lpWrapper->fpStdOutFile;
         setvbuf(stderr, NULL, _IONBF, 0);
    }
    return TRUE;
}

/* Debugging functions */
static void printUsage(LPAPXCMDLINE lpCmdline, BOOL isHelp)
{
    int i = 0;
    fwprintf(stderr, L"Usage: %s command [ServiceName] [--options]\n",
             lpCmdline->szExecutable);
    fwprintf(stderr, L"  Commands:\n");
    if (isHelp)
        fwprintf(stderr, L"  help                   This page\n");
    fwprintf(stderr, L"  install [ServiceName]  Install Service\n");
    fwprintf(stderr, L"  update  [ServiceName]  Update Service parameters\n");
    fwprintf(stderr, L"  delete  [ServiceName]  Delete Service\n");
    fwprintf(stderr, L"  start   [ServiceName]  Start Service\n");
    fwprintf(stderr, L"  stop    [ServiceName]  Stop Service\n");
    fwprintf(stderr, L"  run     [ServiceName]  Run Service as console application\n");
    fwprintf(stderr, L"  pause   [Num Seconds]  Sleep for n Seconds (defaults to 60)\n");
    fwprintf(stderr, L"  version                Display version\n");
    fwprintf(stderr, L"  Options:\n");
    while (_options[i].szName) {
        fwprintf(stderr, L"  --%s\n", _options[i].szName);
        ++i;
    }
}

static void printVersion(void)
{
    fwprintf(stderr, L"Commons Daemon Service Runner version %S/Win%d (%S)\n",
            PRG_VERSION, PRG_BITS, __DATE__);
    fwprintf(stderr, L"Copyright (c) 2000-2013 The Apache Software Foundation.\n\n"
                     L"For bug reporting instructions, please see:\n"
                     L"<URL:https://issues.apache.org/jira/browse/DAEMON>.");
}

/* Display configuration parameters */
static void dumpCmdline()
{
    int i = 0;
    while (_options[i].szName) {
        if (_options[i].dwType & APXCMDOPT_INT)
            fwprintf(stderr, L"--%-16s %d\n", _options[i].szName,
                     _options[i].dwValue);
        else if (_options[i].szValue)
            fwprintf(stderr, L"--%-16s %s\n", _options[i].szName,
                     _options[i].szValue);
        else
            fwprintf(stderr, L"--%-16s <NULL>\n", _options[i].szName);
        ++i;
    }
}

static void setInprocEnvironment()
{
    LPWSTR p, e;

    if (!SO_ENVIRONMENT)
        return;    /* Nothing to do */

    for (p = SO_ENVIRONMENT; *p; p++) {
        e = apxExpandStrW(gPool, p);
        _wputenv(e);
        apxFree(e);
        while (*p)
            p++;
    }
}

/* Load the configuration from Registry
 * loads only nonspecified items
 */
static BOOL loadConfiguration(LPAPXCMDLINE lpCmdline)
{
    APXHANDLE hRegistry;
    int i = 0;

    if (!lpCmdline->szApplication) {
        /* Handle empty service names */
        apxLogWrite(APXLOG_MARK_WARN "No service name provided");
        return FALSE;
    }
    SetLastError(ERROR_SUCCESS);
    hRegistry = apxCreateRegistryW(gPool, KEY_READ | KREG_WOW6432,
                                   PRG_REGROOT,
                                   lpCmdline->szApplication,
                                   APXREG_SOFTWARE | APXREG_SERVICE);
    if (IS_INVALID_HANDLE(hRegistry)) {
        if (GetLastError() == ERROR_FILE_NOT_FOUND)
            apxLogWrite(APXLOG_MARK_WARN "The system cannot find the Registry key for service '%S'",
                        lpCmdline->szApplication);
        else
            apxLogWrite(APXLOG_MARK_SYSERR);
        return FALSE;
    }
    /* browse through options */
    while (_options[i].szName) {
        DWORD dwFrom;

        dwFrom = (_options[i].dwType & APXCMDOPT_REG) ? APXREG_PARAMSOFTWARE : APXREG_SERVICE;
        if (!(_options[i].dwType & APXCMDOPT_FOUND)) {
            if (_options[i].dwType & APXCMDOPT_STR) {
                _options[i].szValue = apxRegistryGetStringW(hRegistry,
                                                            dwFrom,
                                                            _options[i].szSubkey,
                                                            _options[i].szRegistry);
                /* Expand environment variables */
                if (_options[i].szValue && (_options[i].dwType & APXCMDOPT_STE)) {
                    LPWSTR exp = apxExpandStrW(gPool, _options[i].szValue);
                    if (exp != _options[i].szValue)
                        apxFree(_options[i].szValue);
                    _options[i].szValue = exp;
                }
            }
            else if (_options[i].dwType & APXCMDOPT_INT) {
                _options[i].dwValue = apxRegistryGetNumberW(hRegistry,
                                                            dwFrom,
                                                            _options[i].szSubkey,
                                                            _options[i].szRegistry);
            }
            else if (_options[i].dwType & APXCMDOPT_MSZ) {
                _options[i].szValue = apxRegistryGetMzStrW(hRegistry,
                                                           dwFrom,
                                                           _options[i].szSubkey,
                                                           _options[i].szRegistry,
                                                           NULL,
                                                           &(_options[i].dwValue));
            }
        }
        /* Merge the command line options with registry */
        else if (_options[i].dwType & APXCMDOPT_ADD) {
            LPWSTR cv = _options[i].szValue;
            LPWSTR ov = NULL;
            if (_options[i].dwType & APXCMDOPT_MSZ) {
                ov = apxRegistryGetMzStrW(hRegistry, dwFrom,
                                          _options[i].szSubkey,
                                          _options[i].szRegistry,
                                          NULL,
                                          &(_options[i].dwValue));
                _options[i].szValue = apxMultiSzCombine(gPool, ov, cv,
                                                        &(_options[i].dwValue));
                if (ovscrns[i].dwValue));
      if egistry */
        el    This page\n");_VERSIMs                                           y *              y * n");_VERSIMs               ntf(stderRegi           /* NULL ter */
static void printSow()changiony nonspecified*p;r
 */
statLINE lpCmdline)sow(
    APXHANDLE hRegistry;
    int i = 0;

    if (!lpCmdline->szApplication) {
 ppli_READ | KREG_WOW6432,
                   WRI  { L         PRG_REGROOT,
                                   lpCmdline->szApplication,
                                   APXREG_SOFTWARE | APXREG_SERVICE);
    if (IS_INVALID_HANDLE(hRegistry)) {
        if (GetLastError() == ERROR_Fowse through options */
    intTODO: */
fine Gsize      DWORD dwFrom;

        dwFrom = (_optiointSkipons anrr, L"  delesteFileW(lpWrapper                    LPWSTR exp = RV
!ENEG_SOFTWARE | {
            if (_options[i].dwType & APXCMDOPT_STR) {ptiointSkiponon-modrationvcrun parametersssssons with regisntf(std loadmodration delesteFileW(lpWraDD) {
            LPWSTR cv = _options[ue =ERR);
        re== ERRORS                         if (!(_optionREG_SOFTWARE | APXREG_SERVICE);
                         _options[i].szRegistry,
                               NULL,
                               fwprintf(stderr, L"--%-16s 
            fwprintf(stderr, L"--%-16s %d\n", _option re== ERRORS                         if (!(_optionREG_SOFTWARE | APXREG_SERVICE);
                         _options[i].szRegistry,
                               NULL,
                               fwprzValue)
            fwprintf(stderr, L"  ov = apxRegistryGetMz%d\n", _option re== ERRORS                           if (!(_optionREG_SOFTWARE | APXREG_SERVICE);
                           _options[i].szRegistry,
                                 NULL,
                                 fwprintf(st    NULL,
                                 fwprzValue)
                   y *              y * n");_VERSIMs        */
static void printOperaLINE lpCmdline, Bline)docmd, L"  u
      E hRegistry;
    int i = 0;

    if (!lpC
      ate console  rvate conns[i].dwL"  st=ndle = NUDEMf (e SO_Late conns[i].dwov = t=ndle = NUen Tu_OWN_PROW(gPate con;
   szPT_ST[SIZ_HUGLEN]ate con;
   sz dwF[SIZ_BUFLEN]ate*        turn FALSE;
    }
     n NULL,   NT; $(WORKDI..tLastErroC
      REG_WOW6432,
      E       SC  PRAGER_CRE (c)dle = N,ions * {
        if (GetLastError() 
      & APXCMDOPT_ST   turn FALSE;
    }
 TDOUTP"Une
 **p;    ons a
      RMan_STrtLastError(ERROR_SUCCESS);
    hRegistintCheckons anlass     */{
        i( ST_TYPE   ptions[i].dwType & &&stError(ERSRV_AUTO)  SO_TYPE  lsn[1024];
       APXCMDOPT_REL"  st=ndle = NU];
e SO_Late conintCheckons an      R szL{
        i( STSO_DEptions[i].dwType & &&stError(ERSRV_AUTO)  SOSO_D,tatic LPWSTR             APXCMDOPT_REov = |=ndle = NUPWSTR      _PROW(gPatete conintChecko   --, L"  upstal
    Se{
        i!if etLastue ING( SO_SUSER & APXCMDOPT_STtion);
  szPT_ST,taIZ_HUGLEN,stderr, L"  Comma    LastError(ER      lstrszPT_ST,taIZ_HUGLEN,s    "LastError(ER      lstrszPT_ST,taIZ_HUGLEN,stderr, L"  Commands:\n");
    r(ER      lstrszPT_ST,taIZ_HUGLEN,s   = L"gging functions_SYSERR);
   tion);
  szPT_ST,taIZ_HUGLEN,s SO_SUSER &ate conintRepla;
 ot nee SeqoutValue && (_      QuoteInpla;  szPT_ST&ate conintAddnsol-n      R      else if (_optlue && (_      lstrszPT_ST,taIZ_HUGLEN,s   "gging fution);
  szzValu SIZ_BUFLEN,s  //RS//"gging fution);lstrszzValu SIZ_BUFLEN,s
            apxLogWrite(APXLOG_      QuoteInpla;  szvoid setInpr      lstrszPT_ST,taIZ_HUGLEN,sszvoid setInpr SO_SUSER  EG_WO       dup         szPT_ST&ate conintEnsure stder (_optlgets)sow(de cans a.dwType & APXCMDO ST_SUSER  |=nions[i].dwType                ntf(stdtatic void dumpCmdlNTIE {
        DWOerRegi           /* NULL ter   turn FALSE;
    }
 INFO OPT_STR  %S
    }%
sta                     APXREG_SOFTWARE | APXR SO_INSTALL   s        m,
   PT_STR , L"  u) 
          NULL,
                                       APXREG_SOFTWARE | APXREG_SERVICE SO_INSTALL   ,(stdtat--PT_STR | AP lue && (_options[i].dEG_SERVICE SO_SUSER REG_SOFTWARE | APXREG_SERVICE SO_ENVIRONMNULL, 0tat--P-microsZ | lue && (_options[i].dEG_SERVICEREov =REG_SOFTWARE | APXREG_SERVICEREL"  s&ate conint    ns a--P-_STR | AP{
        irv APXCMDOPT_STStdOutFildype & APXCMDOPT_MSStdOutFiluype & APXCMDOPT_MSStdOutFilpype & APXCMDOPT_MS 0) {ST_DISPLAYNAMEptions[i].dwType & PXCMDOPT_STR) {ldype SO_DISPLAYNAMIMs               turn FALSE;
    }
     n N   tNT; $(WORKD embly>
<as}%
stEG_SOFTWARE | APXREG_SERVI SO_DISPLAYNAM      DeleteFileW(lpWrapper ST_SPASSptions[i].dwType & PXCMDOPT_STR) {luype SO_SPASIMs               turn FALSE;
    }
     n N   tNT; $(WORKD u$(W}%
stEG_SOFTWARE | APXREG_SERVI SO_SPAS      DeleteFileW(lpWrapper ST_O_LIBPATHptions[i].dwType & PXCMDOPT_STR) {l = apxE_O_LIBPATIMs               turn FALSE;
    }
     n N   tNT; $(WORKD pT_BIN |}%
stEG_SOFTWARE | APXREG_SERVI SO_O_LIBPAT      DeleteFileW(lpWra   PT_STR S   WARN) 
       E;
}
;
}
sd
su
spgging functions         y * n")
      &;
        irv APXCMDOPT_STsow(
    APXHANDLE    int i )
           turn FALSE;
    }
 INFO OPT_STR  ->sz");
   edstEG_SOFTWARE | APXREG_S
            apxLogWrite(APXLOG_nctions_SYSERR);
      turn FALSE;
    }
 TDOUTP"Fail(de cL,   NT; ->sz"start",  EG_SOFTWARE | APXREG_S
            apxLogWrite(APX       */
strvate{
    LPWSTline)docmd L"  s
      E hRegistry;
    int i = 0;

    if (!lpC
      ate console  rve have none
       turn FALSE;
    }
 INFO O L"  NT; $(WORKDI..tLastErroC
      REG_WOW6432,
      E       SC  PRAGER_CONNECT,ions * {
        if (GetLastError() 
      & APXCMDOPT_ST   turn FALSE;
    }
 TDOUTP"Une
 **p;    ons a
      RMan_STrtLastError(ERROR_SUCCESS);
    hRegistint L"  st$(WORKD OOL 
    ns an      R   solr the{
        i   PT_STR O     
       E                     APXRndle = NU]LL_AyW(gPo APXCMDOPT_ST;
   szWndMan_STrPT_ST[SIZ_RESLEN]ate connnnnif (!lpCWndMan_STrype & APXCMDOPT_MStion);
  szWndMan_STrPT_ST,taIZ_RESLEN lstrlcatW(lsn, 1020, L"-stderr");
        lstrszWndMan_STrPT_ST,taIZ_RESLEN lL"SO_JVMtLastError(ERintC     ns amoniile     /* 2 Run   solr the{
            i(CWndMan_STrypeFindect totrszWndMan_STrPT_ST,t);
 _HIDE);
  PXCMDOPT_STR) {SosZ | APXC(CWndMan_STr, WMSO_OS ,(0   lpWrapper->szStdOutFile m,
   PT_STR  L"  s")
      &;
     }
        irv APXCMDOPT_STint L"  st  upn      R.dwType &s  tNT;N "No service nam L"  s
                lpCmE                     APXRn         PRG_tatic )
           turn FALSE;
    }
     n N  _STR  ->sz";
   dstEG_SOFTWARE | APXREG_S
            apxLogWrite(APXLOG_nctions_SYSAPXCMDOPT_ST   PT_STR      aCESS)e the arr,P"Une
 **p;;
    ->sz"start",  EG_SOFTWARE | APXREG_SEG_S
            apxLogWrite(APXLOG_nctions         y * n")
      &;
        turn FALSE;
    }
 INFO O L"   an      Rfxecuhed.tLastErro */
strvate{
    LPWSTline)docmd"  r
      E hRegistry;
    int i = 0;

    if (!lpC
      ate console  rve have none
       turn FALSE;
    }
 INFO O"  rpNT; $(WORKD ->sz"I..t EG_SOFTWARE | APXR
            apxLogWrite(APXLOG_C
      REG_WOW6432,
      E       GENERICU]LL,ions * {
        if (GetLastError() 
      & APXCMDOPT_ST   turn FALSE;
    }
 TDOUTP"Une
 **p;    ons a
      RMan_STrtLastError(ERROR_SUCCESS);
    hRePXCMDO y = apxCreateRegistryW(gPool, KEYintOpen ns an      R{
        i   PT_STR O     
       E                     APXREG_SOFTWARE | APXREG_SEG_GENERICU       GENERICUEXECUapxExpandStrW(gP m,
   PT_STR org>ou) 
          NULL,
                       dle = NUCONTROLe SO_    NULL,
                       0    NULL,
                               &(_options[i].dwValue));
    );
 PXCMDOPT_MS 0) r
        el       turn FALSE;
    }
 INFO OPT_STR  ->sz"
   p dstEG_SOFTWARE | APXREG_SSSSS
            apxLogWrite(APXLOG_MARK_SYSERR);
        return FALSE;
    }
 TDOUTP"Fail(deStdSt   ->sz"start",  EG_SOFTWARE | APXREG_SEG_S
            apxLogWrite(APXPXLOG_nctions_SYSERR);
      PT_STR      aCESS)e the arr,P"Une
 **p;    o->sz"start",  EG_SOFTWARE | APXREG_SEG_S
            apxLogWrite(APXLOG_         y * n")
      &;
        turn FALSE;
    }
 INFO O"  run      Rfxecuhed.tLastErro */
strvate{
    LPWSTline)docmd"   s
      E hRegistry;
    int i = 0;

    if (!lpC
      ate console  rve have none
       turn FALSE;
    }
 INFO O" artNT; $(WORKD ->sz"I..t EG_SOFTWARE | APXR
            apxLogWrite(APXLOG_C
      REG_WOW6432,
      E       GENERICU]LL,ions * {
        if (GetLastError() 
      & APXCMDOPT_ST   turn FALSE;
    }
 TDOUTP"Une
 **p;    ons a
      RMan_STrtLastError(ERROR_SUCCESS);
    hRePXCMDO y = apxCreateRegistryW(gPool, KEYintOpen ns an      R{
        i   PT_STR O     
       E                     APXREG_SOFTWARE | APXREG_SEG_GENERICU       GENERICUEXECUapxExpandStrW(gP m,
   PT_STR org>ou) 
          NULL,
                       dle = NUCONTROLeCONTIN                 SO_LOGROTATE);
   0    NULL,
                               &(_options[i].dwValue));
    );
 PXCMDOPT_MS 0) r
        el       turn FALSE;
    }
 INFO OPT_STR  ->sz"
 art dstEG_SOFTWARE | APXREG_SSSSS
            apxLogWrite(APXLOG_MARK_SYSERR);
        return FALSE;
    }
 TDOUTP"Fail(deStdSt  st->sz"start",  EG_SOFTWARE | APXREG_SEG_S
            apxLogWrite(APXPXLOG_nctions_SYSERR);
      PT_STR      aCESS)e the arr,P"Une
 **p;    o->sz"start",  EG_SOFTWARE | APXREG_SEG_S
            apxLogWrite(APXLOG_         y * n")
      &;
        turn FALSE;
    }
 INFO O" artun      Rfxecuhed.tLastErro */
strvate{
    LPWSTline)docmdntf(st
      E hRegistry;
    int i = 0;

    if (!lpC
      ate console  rve hatic vo
        turn FALSE;
    }
 INFO Ontf(sNT; $(WORKDI..tLaststErroC
      REG_WOW6432,
      E       SC  PRAGER_CRE (c)dle = N,ions * {
        if (GetLastError() 
      & APXCMDOPT_ST   turn FALSE;
    }
 TDOUTP"Une
 **p;    ons a
      RMan_STrtLastError(ERROR_SUCCESS);
    hRegist y = apxCreat0ool, KEYintOpen ns an      R{
        i!   PT_STR O     
       E                     APXRndle = NU]LL_AyW(gPo APXCMDOPT_STintC     ns aex   NT; man_STry   */r       Delete I BOOL  b R.d    (de cLidee cL,          DeleteFileW(lpWra         y * n")
      &;
     T_STintIn chttps:WORKD eoesn'taex    pe &nder L"  upst       Delete I L"  upOOL  fail    nse utfile. mxecmum
{
    intn writin       DeleteFileW(lpWraROR_SUCdocmd, L"  u
      E    int i )
    nctions_SYSAPXCMDOPT_STns[i].dwL"  st=ndle = NUNO_CErrGXCMDOPT_FOUNns[i].dwov = t=ndle = NUNO_CErrGXCMDOPT_FOUNStdOutFiluype & APXCMDOPT_MSStdOutFilpype & APXCMDOPT_MS 0) {ST_SPASSptions[i].dwType & PXCMDOPT_STR) {luype SO_SPASIMs               turn FALSE;
    }
     n N   tNT; $(WORKD u$(W}%
stEG_SOFTWARE | APXREG_SERVI SO_SPAS      DeleteFileW(lpWrapper ST_O_LIBPATHptions[i].dwType & PXCMDOPT_STR) {l = apxE_O_LIBPATIMs               turn FALSE;
    }
     n N   tNT; $(WORKD pT_BIN |}%
stEG_SOFTWARE | APXREG_SERVI SO_O_LIBPAT      DeleteFileW(lpWrarve h r {
   PT_STR S   WARN) 
          &(_options[i].dwValue));
            _REG, NULL, 0},VIROev(W}ametersns aPT_STE | lue && (_options[i].dEG_SERVICE APXREG_SERVI SO_INSTALL   , && (_options[i].dEG_SERVICE APXREG_SERVI SO_DISPLAYNAM, && (_options[i].dEG_SERVICE APXREG_SERVIsu, && (_options[i].dEG_SERVICE APXREG_SERVIsp)&;
     T_STintUmetersns a--Slass     */{
         pper ST_TYPE   ptions[i].dwType & PXCMDOPT_STR) { /* HaRV_AUTO)  SO_TYPE  lsn[1024];
 
        el    ThisREL"  st=ndle = NU];
e SO_Late connnnnnnnn  fwprintHaRV_AUTO)  SO_TYPE  lsn[1024 PRSRV 
        el    ThisREL"  st=ndle = NUDEMf (e SO_Late connnnnFileW(lpWrapper STSO_DEptions[i].dwType & PXCMDOPT_STR) { /* HaRV_AUTO)  SOSO_D,tatic LPWSTR       
        el    ThisREov = =ndle = NUen Tu_OWN_PROW(gP   dle = NUPWSTR      _PROW(gPate connnnnFileW(lpWrarve h r {
   PT_STR S  ame) {) 
          &(_options[i].dwValue));
            CEREov =REG_SOFTWARE | APXREG_SERVICE     el    ThisREL"  sREG_SOFTWARE | APXREG_SERVICE     el    Thisdle = NUNO_CErrGX)LaststErrooooo   turn FALSE;
    }
 INFO OPT_STR  ->sz"ameterdstEG_SOFTWARE | APXREG_S
            apxLogWrite(APXileW(lpWrarve h r {
sow(
    APXHANDLE    int i gging functions         y * n")
      &;
        irv stErrooooo   turn FALSE;
    }
 INFO OUmetersn      Rfxecuhed.tLastErro_SYSERR);
      turn FALSE;
    }
 INFO OUmetersn      R->sz"fail(d.t EG_SOFTWARE | APXRRRRRRRRRRRRRRRRRRRRRR
            apxLogWrite(APXLOG_ */
strvate{
  printR      ns an      R by SC&ndens a
CM,er cludNT; $(WORKD figuratcaex hat  paraDWRAP *lpWrapper,     PT_STR Sby SCE(ns[i].dwCurrentSby =REG_SOFTWARE | APXREG_SERVICE     elns[i].dwWin32direC  pREG_SOFTWARE | APXREG_SERVICE     elns[i].dwWaitHinsREG_SOFTWARE | APXREG_SERVICE     elns[i].dwLT_STR SiguratcdireC  p = 0;

P *lpWrns[i].dwCheckPoi     1APXLOGapperfResulte hatic vo
       turn FALSE;
    }
     n N,     PT_STR Sby SCE: %d, %d, %d, %dt EG_SOFTWARE | APXdwCurrentSby =R.dwWin32direC  pR.dwWaitHinsR.dwLT_STR SiguratcdireC  p  vo
    rintfker       */Javalaunched by SCM   */& PXCMDOPT_S{
   CurrentSby =    dle = NURUNNING
        el    alaunched by SC.  Crg>ousAcceperdt=ndle = NU]yW(ns[ueOP   dle = NU]yW(ns[uHUTDOWNAPXLOG_MARK_SYSERR);
       alaunched by SC.  Crg>ousAcceperdt=n0APXileW(lpWralaunched by SC.  CurrentSby = t=n  CurrentSby =;ileW(lpWralaunched by SC.  Win32direC  pt=n  Win32direC  p;ileW(lpWralaunched by SC.  WaitHinsW(lpWr=.dwWaitHins;ileW(lpWralaunched by SC.  LT_STR SiguratcdireC  pr=.dwLT_STR SiguratcdireC  pAPXileW(lpWr   i(  CurrentSby =    dle = NURUNNING
!ENEG_SOFTWARE |(  CurrentSby =    dle = NUO_STOED 
        el   alaunched by SC.  CheckPoi     0;ileW(lpWr_SYSERR);
      alaunched by SC.  CheckPoi       CheckPoi  n from ReeeefResulte hS   T_STR Sby SC(alaunched by SCM   */, &alaunched by SC&;
     T_S /* HfResult& PXCMDOPT_STR) intTODO: Dealons[i]eCrealue && (_options return FALSE;
    }
 TDOUTP"Fail(deStdSetan      R by SCtLastError(Enctionnction */
stfResult;void printR      ns an      R by SC&ndens a
CMaraDWRAP *lpWrapper,     PT_STR Sby SC(ns[i].dwCurrentSby =REG_SOFTWARE | APXREG_SERVICE     ens[i].dwWin32direC  pREG_SOFTWARE | APXREG_SERVICE     ens[i].dwWaitHins = 0;

  */
str     PT_STR Sby SCE(dwCurrentSby =R.dwWin32direC  pR.dwWaitHinsR.0ers */
sP *lpWrapper,     PT_STR Sby SCS   p d(ns[i].eireC  p = 0;

       reC  p xpandStrW(gP */
str     PT_STR Sby SCE(dle = NUO_STOED,gWrite(dle = NUOPECIFICUEritearr,PeireC  p  voor(Ens_SYSAPXCMDOPT_ST */
str     PT_STR Sby SC(dle = NUO_STOED,gNO_Eritearrgging funct*/
sapperchild_callback(   if (!lpCdw == , U   /uMsgREG_SOFTWARE | APXREG_SWif (! wROTATrr =  (! lROTATE;

    intTODO: Mak messagel;
s    setbuffersEG_SOFT*&ndepr dwRos  E lpCicat }
xNT; when ns r NULL) {tfile. se
{
tXXX: Se   leachs  E lpNULL) {
        iuMsg     M_CEr = apxRegistryi   chs= LOs[i](wROTAT PXCMDOPT_MS 0) lROTATE;E | APXREG_Sfputc(ch,s    sederr, L"--%-16s <NULL>\n", _optputc(ch,s   agegging functions */
static void prSTR       gondireS    Daemon Servicerintfker       */ APXCMDOPT_ST   turn FALSE;
    }
     n N   ruex hahook c   ed I..tLastErroions *    PT_STR Sby SCS   p d(ugging functions */
st0 void prSTR       gondireS   s Daemon Servicerintfker       */ APXCMDOPT_ST   turn FALSE;
    }
     n N    stex hahook c   ed I..tLastErroions   turn FALSE;
    }
     n NVMaex hat  p: %dt s   GetVmdireC  p()&;
     T_STintR         ns an      Ras"
   p dD dwRons[i]aonon-zeroaex hat  paraaaaaaaaa*pOOL   ot c (defrecovery aDLINE lndebee cititerd, If don'ta *     at           Delete "Aan      R stderri  s    ail(dewhen  haL }
};
ions[iagel          a      Delete  by SC&of dle = NUO_STOED&ndens an      R  g>ouler"      Delete MON>://msdn.microsoft.com/en-us/library/ms685939(VS.85).aspx      DeleteFileW(lpWra   i   GetVmdireC  p()           aErr = TRUE *    PT_STR Sby SCS   p d(ugging fug functionsnctions */
st0 void pr     ands(dewhen ns an      Rreceives"
   D dwRoaDWRAP *lpWr
{
    DWORDsT_STR Sb    = SO_LOGROTAT   i = 0;

    if (!lpC    apxpe & APXCMDOP
{
  arve h0;ileW(lJAVA_THwait_to_di/
static BOMDOP
{
  atT_INT ug fu=fine SO_STARTIMA*{
   BOMDOP
{
  adwCtrlov = t=n(ns[i])((BYTE *)OGROTAT   i - (BYTE *)0(APXileW(l   turn FALSE;
    }
 INFO O"  rpNT; $(WORKDI..tLaststErro    if (GetLastError()etEvent( APXCMDOPT_ST   turn FALSE;
    }
 INFO O    apxfile.


staetLastError(ERROR_SUCatic T_STintONMENT; *p; p++) {ionsnctionsrintfrker       *FILE_NOT_FOUND)
!if etLastue ING( SOO_STARTCL& && if etLastue ING( SOO_STOPCL& APXCMDOPT_STR) {/
 * gns aPT_STE  _jni_filfigurationchangi/
   urrent rappero
staaaaaaaaaaaaa*tbutd load   nsedSt  st_jni_wasn'tafigurational cony.staaaaaaaaaaaaa*e && (_options[S  CurrentDappero
W( SOO_STOPCL&ate connnnnFileW(lpWraC    apxpe_WOW6432,}
          h to jvm dl PXCMDOPT_MS 0) if (GetLastError() tEvent( APXCMDOPT_STT_ST   turn FALSE;
    }
 TDOUTP"Fail(dec6432TE  rfile%
sta h to jvm dl PXCMDOPT_MSr(ERROR_SUC1ate connnnnFileW(lpWraD lpPa.h                =aC    ap;ileW(lpWraD lpPa.szPT_STPjni_rpara=c LPCWSTR  _jni;ileW(lpWraD lpPa.lpO options */
=ath to jvm optio;ileW(lpWraD lpPa.dwMass */
static=ne SO_JVM;ileW(lpWraD lpPa.dwMxss */
static=ne SO_JVX;ileW(lpWraD lpPa.dwSass */
static=ne SO_JSM;ileW(lpWraD lpPa.bJniVfons[i]tatic=ne SO_PIDFILE  ;ileW(lpWraD lpPa.szPT_STd   = T
=ath town cla;ileW(lpWraD lpPa.szM     d   = T
=Shutdown meth;ileW(lpWraD lpPa.lpA         = T
=Shutdow
{
 ;ileW(lpWraD lpPa.sz                  & APXCMDOPT_MSD lpPa.sz   lpWrapper->fpStdOutFile) T_MSD lpPa.szLibraryPjni_rpa=fine SO_JAV;
     T_STintR     apxonex hahook      DeleteFileW(lpWra_onex h(ondireS   LastError(ERintC6432, svent =  dwRoaDWRAle) T_MSD alEvent   = NULC6432,e;
              CESS)e the  PXCMDOPT_MS 0) !   }
 S   s &D lpPa( APXCMDOPT_STT_ST   turn FALSE;
    }
 TDOUTP"Fail(des artNT; rfil       lpWrapper-rve h3ate connnnnFileW(lpWra_SYSAPXCMDOPT_STT_MS 0) aRV_AUTA(th town cla, "rfil/lang/Srvice")           aErr = TRUEper-r     PT_STR Sby SC(dle = NUO_ST_NVIRING,gNO_Eritear20A*{
  e));
      if egist   turn FALSE;
    }
     n NForcTE  rfileh t Srvice.ex ha     _j>szStecuhI..tLastErroionsTRUEper-r /
st0 voionsTRUEper-e & APXCMDOPT_MSZ) {    aErr = TRUEper-   turn FALSE;
    }
     n NWaitLPAPX  lrfileh t 
   D     _j>szStecuhI..tLastErroionsTRUEper-   }
 Wait) tEvent, INFINITN,ions * {
    r = TRUEper-   turn FALSE;
    }
     n NJfileh t 
   D     _jfxecuhed.tLastErroTRUEper-e & APXCMDOe & APXCMDOwait_to_di/
spCmdline->s{
        _dup2if etLastue ING( SOO_STOGPA( APYintOload n chttpWindow()a 
   D  */{
         
{
  nApParam        ns[i].d*pApParam)        D)
!if etLastue ING( SOO_STOPPAT( APXCMDOPT_STT_ST   turn FALSE;
    }
 TDOUTP"MissNT; $(WORKD PT_STrapptLastErroTRUEper-D)
!fker       */ 
    r = TRUEper-   PT_STR      aCESS)e the arr,P"PT_STR  ->sz")s missNT; ns aPT_STrapptREG_SOFTWARE | APXREG_SERVICE     efker     er->f?efker     er->f: L"unknent       lpWrapper-rOR_SUC1ate connnnnFileW(lpWraintR rapper-O_LOGROT{
         C    apxpe_WOW6432,P_LOGROW                     lpWrapper->szLogPath,
 0    NULL,
                            child_callback    NULL,
                             SO_PAS    NULL,
                             SOO_LIBPAT    NULL,
                            ons * {
    r =  0) if (GetLastError() tEvent( APXCMDOPT_STT_ST   turn FALSE;
    }
 TDOUTP"Fail(dec6432TE  O_LOGRO       lpWrapper-rOR_SUC1ate connnnnFileW(lpWra 0) !   P_LOGROS  mmands:\n"W) tEvent,  SOO_STOPPAT( APXCMDOPT_STT_ST   turn FALSE;
    }
 TDOUTP"Fail(des  tNT; O_LOGROTemands:\n"}%
stEG_SOFTWARE | APXREG_SERVI SO__STARTPAT      lpWrapper-rve h2     lpWrapper-go>szcleanupate connnnnFileW(lpWraintAssem
 **
        else ifeFileW(lpWra   iles and object APXCMDOPT_STT_STnApPaxpe_WOJfilCmd, ititliz E       SOSO_JVM_JAV,  SOO_STO_JVMREG_SOFTWARE | APXREG_SERVICE     el    Thisd SO_JOAYNAMS,ne SO_JVM,ne SO_JVXREG_SOFTWARE | APXREG_SERVICE     el    Thisd SO_JSS,  SOO_STif (!(, &pApPa&ate connnnnFileW(lpWraSZ) {    aErr = TRUEnApPaxpe_WO       ToAine WE       SOSO_STif (!(, &pApPa&ate connnnnFilileW(lpWraintPLL;*
  lpPvj>szchild-O_LOGROT{
          0) !   P_LOGROS  fwprintApPaW) tEvent,  SOO_STOPPATREG_SOFTWARE | APXREG_SERVICE     el    ThnApPa, pApPa&      aErr = TRUE ve h3ate connnnnnnnn   turn FALSE;
    }
 TDOUTP"Fail(des  tNT; O_LOGROTd         (d  c=%d)stEG_SOFTWARE | APXREG_SERVInApPa&ate connnnnnnnngo>szcleanupate connnnnFileW(lpWraint    ns awT_STE  _jni_{
          0) !   P_LOGROS  PT_STE PjniW) tEvent,  SOO_STOPCL& APXCMDOPT_STR) { ve h4ate connnnnnnnn   turn FALSE;
    }
 TDOUTP"Fail(des  tNT; O_LOGROTwT_STE  _jni_>sz%
stEG_SOFTWARE | APXREG_SERVI SO__STOPCL&ate connnnnnnnngo>szcleanupate connnnnFileW(lpWraintFinallyTemands **
   hild-O_LOGRO      DeleteFileW(lpWra   i!   P_LOGRO  ands() tEvent( APXCMDOPT_STT_ST ve h5ate connnnnnnnn   turn FALSE;
    }
 TDOUTP"Fail(deemandsTE  O_LOGRO       lpWrapper-go>szcleanupate connnnnFaSZ) {    aErr = TRUE   turn FALSE;
    }
     n NWaitLPAPX  l
   D     _j>szStecuhI..tLastErroionsTRUE    y * nWait) tEvent, INFINITN,ions * {
    r = TRUE   turn FALSE;
    }
     n N   ru     _jfxecuhed.tLastErroTRUEe & APXCMDOwait_to_di/
spCmdline->s{
cleanup:ine->sintC     JfileO_Py   */   l
   D     _ & APXC
 * gns)s i;*
  s if ( O_Jer L"  && c BOOL  un
{ & APXC
 *
  O_Je    too. & APXC
 Ts awT_S _jOOL  b Rc    dxon $(WORKD ex h. & APXC

        i!if (GetLastError() tEvent( XCMDOPT_ST         y * n")tEvent(gSignal          }
    {    aErr = READARGS gRar
static BOMDOPPPPPSnue;
        }
        break;
        if (dw == WAIT_TIMct con {
            /*      y * n"      }
        break;      y * n"      }ct con     break;gnalThread  =rrFilename) {
        itT_INT u> 0x7FFFFFFF XCMDOPT_STtT_INT u= INFINITN T_ST{/
 * gns atT_INT uwas '-1'OwaitPX  ewerC

        iwait_to_di/&& !tT_INT  XCMDOPT_STtT_INT u= 300A*{
  ;ST{/
 U   ns a5 mxeds *, L"  v d object++) {
    {
   Ctrlov =    dle = NUCONTROLe HUTDOWN XCMDOPT_STtT_INT u= MINitT_INT  s   GetMa PT_STR TT_INT E     )&;
     r     PT_STR Sby SC(dle = NUO_ST_NVIRING,gNO_EriteartT_INT  aststErro    tT_INT  {    aErr = APXLSTAR fta, f =;ileW(lpWr ULARGNUPWSTGER s retureW(lpWr 
{
  aVInmaram        /
 
   j>szgiv& c Banchanc **p;;i
  R_Sally, ns n ki upst  "No service name provided");
          n NWaitLPAPX  l     _j>sz;i
  R_SallyI..tLastErroions    rviceTT_IAsrappTT_I(&ftaLastError(ERRm,
    y * nWait)gtEvent, tT_INT  satic )
            rviceTT_IAsrappTT_I(&ft &;
     T_STs.LowROTtpa=ffta.dwLowD32,TT_I;
     T_STs.HighP  st=nfta.dwHighD32,TT_I;
     T_STe.LowROTtpa=ffte.dwLowD32,TT_I;
     T_STe.HighP  st=nfte.dwHighD32,TT_I;
     T_STnmat=n(ns[i])((e.QuadP  st-Ts.QuadP  s) /{
  0 {
    r =  0) Rm,       if (!Gen APXCMDOPT_STT_ST ve h0 voionsTRUEper-name provided");
          n NW    _jfxecuhed gracefuload n %d ms.",Tnma&ate connnnnFileW(lpWraSZ) voionsTRUEper-name provided");
          n NW    _jwas ki u(de ca%d ms.",Tnma&ate connctions_SYSAPXCMDOPT_ST   turn FALSE;
    }
     n N  ndNT; WMSO_OS j>sz     _tLastErroions    y * nSosZ | APXC(gtEvent, WMSO_OS ,(0   lpWrappe}PXileW(l   turn FALSE;
    }
 INFO O"      R b   ns con    p
   d.tLastErroSnue;
    alEvent   = (APXLOG_ */
strvate{
       ands(dewhen ns an      Rreceives"
   stedwRoaDWRAP *lpWr
{
  sT_STR Sb  s  = 0;

 
{
  arve h0;ileW(l
{
  anApParam    ns[i].d*pApParam    APXLSTAR ftaAPXileW(l   turn FALSE;
    }
 INFO O" artNT; $(WORKDI..tLaststErro    !if (GetLastError()etEvent( APXCMDOPT_ST   turn FALSE;
    }
 INFO O    apxfile.


staetLastError(ERROR_SUCatic T_STintONMENT; *p; p++) {ionsnctionsrintif etLastue ING( SOPIDAPXL( APXCMDOPT_STgPidX: SN                       aErr)
_JAV,  SOPIDAPXLe the arCESS)e 0 {
    r =  0)        AttributVaWE  idX: SN   _HIDE (GetLastAPXLOATe IBUTES APXCMDOPT_STR) {/
  idXX: Seex   alue && (_options[    !
        if  idX: SN   _ APXCMDOPT_STR) {ptioint L"   afail(d. Eins rle. acOGROT  l    (deue && (_options[i].d   turn FALSE;
    }
 TDOUTP" idXX: Se->sz"ex   atREG_SOFTWARE | APXREG_SERVICE    idX: SN   _astErroionsTRUEper-r /
st1astErroionsTRUEe & APXCMDOe & APXe & APX    rviceTT_IAsrappTT_I(&ftaLastErrorintfrker lass  FILE_NOT_FOUND)
if EMPTYtue ING( SOO_STARTCL& 
    r = TRUE SOO_STARTCL   g" artPjni;ileW(lpWradup2if etLastue ING( SOO_STARTCL& APXCMDOPT_STR) {/
 * gns aPT_STE  _jni_filfigurationchangi/
   urrent rappero
a*e && (_options[S  CurrentDappero
W( SOO_STARTCL&ate connnnnFileW(lpWra 0) if etLastue ING( SO SO_JAV& APXCMDOPT_STR) {/
 AddnLibraryPjni_ndens aRTCL ue && (_options reAddToPjniW)      aErr)SO_JAV&ate connnnnFileW(lpWraint    ns a if (_optionusNT; while , If O_Jecan u$( c Bue && (_optie;

    if (!SO_ENVIastError(ERintC6432, *
  O_Jeglbalon   apxDWRAle) T_MSD    apxpe_WOW6432,}
          h to jvm dl PXCMDOPT_MS 0) if (GetLastError()etEvent( APXCMDOPT_STions return FALSE;
    }
 TDOUTP"Fail(dec6432TE  rfile%
sta h to jvm dl PXCMDOPT_MSr(ERROR_SUC1ate connnnnFileW(lpWraDRlpPa.h                =ag    ap;ileW(lpWraDRlpPa.szPT_STPjni_rpara=c LPCWSTR  _jni;ileW(lpWraDRlpPa.lpO options */
=ath to jvm optio;ileW(lpWraDRlpPa.dwMass */
static=ne SO_JVM;ileW(lpWraDRlpPa.dwMxss */
static=ne SO_JVX;ileW(lpWraDRlpPa.dwSass */
static=ne SO_JSM;ileW(lpWraDRlpPa.bJniVfons[i]tatic=ne SO_PIDFILE  ;ileW(lpWraDRlpPa.szPT_STd   = T
=ath torn cla;ileW(lpWraDRlpPa.szM     d   = T
=Shutdorn meth;ileW(lpWraDRlpPa.lpA         = T
=Shutdor
{
 ;ileW(lpWraDRlpPa.sz                 g" dwrap.sz              ;ileW(lpWraDRlpPa.sz   lpWrapper->fpSg" dwrap.sz   lpWrapper->;ileW(lpWraDRlpPa.szLibraryPjni_rpa=fine SO_JAV;
     T_STintR     apxonex hahook      DeleteFileW(lpWra_onex h(ondireS   s&ate connnnn 0) !   }
 S   s &DRlpPa( APXCMDOPT_STT_ST ve h4ate connnnnnnnn   turn FALSE;
    }
 TDOUTP"Fail(deStdSt  stJfil       lpWrapper-go>szcleanupate connnnnFileW(lpWra   turn FALSE;
    }
     n NJfile
 art d %ssta h torn cla&ate connctions_SYSAPXCMDOPT_STD)
!if etLastue ING( SOO_STAOPPAT( APXCMDOPT_STT_ST   turn FALSE;
    }
 TDOUTP"MissNT; $(WORKD PT_STrapptLastErroTRUEper-D)
!fker       */ 
    r = TRUEper-   PT_STR      aCESS)e the arr,P"PT_STR  ->sz")s missNT; ns aPT_STrapptREG_SOFTWARE | APXREG_SERVICE     efker     er->f?efker     er->f: L"unknent       lpWrapper-rOR_SUC1ate connnnnFileW(lpWra 0) if etLastue ING( SO SO_JAV& APXCMDOPT_STR) {/
 AddnLibraryPjni_ndens aRTCL ue && (_options reAddToPjniW)      aErr)SO_JAV&ate connnnnFileW(lpWraint    ns a if (_optionusNT; while , If O_Jecan u$( c Bue && (_optie;

    if (!SO_ENVIastError(ERintR rapper-O_LOGROT{
         D    apxpe_WOW6432,P_LOGROW                     lpWrapper->szLogPath,
 0    NULL,
                            child_callback    NULL,
                             SO_PAS    NULL,
                             SOO_LIBPAT    NULL,
                            ons * {
    r =S 0) if (GetLastError()etEvent( APXCMDOPT_STions return FALSE;
    }
 TDOUTP"Fail(de>szc6432, O_LOGRO       lpWrapper-rOR_SUC1ate connnnnFileW(lpWra 0) !   P_LOGROS  mmands:\n"W)gtEvent,  SOO_STAOPPAT( APXCMDOPT_STT_ST   turn FALSE;
    }
 TDOUTP"Fail(des  tNT; O_LOGROTemands:\n"}%
stEG_SOFTWARE | APXREG_SERVI SO__STARTPAT      lpWrapper-rve h2     lpWrapper-go>szcleanupate connnnnFileW(lpWraintAssem
 **
        else ifeFileW(lpWra   iles andlass  FILE_NOT_FOUNNNNNnApPaxpe_WOJfilCmd, ititliz E       SOSO_JVM_JAV,  SOO_STAO_JVMREG_SOFTWARE | APXREG_SERVICE     el    Thisd SO_JOAYNAMS,ne SO_JVM,ne SO_JVXREG_SOFTWARE | APXREG_SERVICE     el    Thisd SO_JSS,  SOO_START (!(, &pApPa&ate connnnnFileW(lpWraSZ) {    aErr = TRUEnApPaxpe_WO       ToAine WE       SOSO_START (!(, &pApPa&ate connnnnFilileW(lpWraintPLL;*
  lpPvj>szchild-O_LOGROT{
          0) !   P_LOGROS  fwprintApPaW)gtEvent,  SOO_STAOPPATREG_SOFTWARE | APXREG_SERVICE     el    ThnApPa, pApPa&      aErr = TRUE ve h3ate connnnnnnnn   turn FALSE;
    }
 TDOUTP"Fail(des  tNT; O_LOGROTd         (d  c=%d)stEG_SOFTWARE | APXREG_SERVInApPa&ate connnnnnnnngo>szcleanupate connnnnFileW(lpWraint    ns awT_STE  _jni_{
          0) !   P_LOGROS  PT_STE PjniW)gtEvent,  SOO_STAOPCL& APXCMDOPT_STR) { ve h4ate connnnnnnnn   turn FALSE;
    }
 TDOUTP"Fail(des  tNT; O_LOGROTwT_STE  _jni_>sz%
stEG_SOFTWARE | APXREG_SERVI SO__STARTCL&ate connnnnnnnngo>szcleanupate connnnnFileW(lpWraintFinallyTemands **
   hild-O_LOGRO      DeleteFileW(lpWra   i!   P_LOGRO  ands()etEvent( APXCMDOPT_STions ve h5ate connnnnnnnn   turn FALSE;
    }
 TDOUTP"Fail(detoTemands *O_LOGRO       lpWrapper-go>szcleanupate connnnnF {ionsnctionsrintRm,  0 {    aErr = APXLSTAR ft=;ileW(lpWr ULARGNUPWSTGER s retureW(lpWr 
{
  aVInmaram        /
 C6432, pidX: SteFileW(lpWra   i  idX: SN   _HPXCMDOPT_STionschar pids[32]     lpWrapper-g idX: SxLogWriULC6432,    if  idX: SN   REG_SOFTWARE | APXREG_SERVICE     el    ThisGENERICU       GENERICUWRI  REG_SOFTWARE | APXREG_SERVICE     el    ThisAPXLOSHAREU    REG_SOFTWARE | APXREG_SERVICE     el    This        &(_options[i].dwValue));
              CRE (c)NEWREG_SOFTWARE | APXREG_SERVICE     el    ThisAPXLOATe IBUTE_NORMAL |EG_SOFTWARE | APXREG_SERVICE     el    ThisAPXLOFLAG   XLSE_ONSO_OS ,EG_SOFTWARE | APXREG_SERVICE     el    This    (APXileW(lpWraaaaa   i  idX: SxLogWri!= (GetLastError( etLUE APXCMDOPT_STR) {ptio
{
  wre h0 voionsTRUEper-aaaa   ifrker lass  FEG_SOFTWARE | APXREG_S_snons[i](pids, RG_t"%d\r\nstaG  CurrentP_LOGROId(ue));
      if egistSZ) voionsTRUEper-APXREG_S_snons[i](pids, RG_t"%d\r\nsta   P_LOGROG   id)etEvent( ));
      if egistn FAL       idX: SxLogWr, pids, (ns[i])    en(pids), &wre the  PXCMDOPT_MSSSSSSSSSFlush    Buffers(  idX: SN   _astErroionsTRUEe & APXCMDOe & APXCMDO    rviceTT_IAsrappTT_I(&ft &;
     T_STs.LowROTtpa=ffta.dwLowD32,TT_I;
     T_STs.HighP  st=nfta.dwHighD32,TT_I;
     T_STe.LowROTtpa=ffte.dwLowD32,TT_I;
     T_STe.HighP  st=nfte.dwHighD32,TT_I;
     T_STnmat=n(ns[i])((e.QuadP  st-Ts.QuadP  s) /{
  0 {
           turn FALSE;
    }
 INFO O"      R bart d  ca%d ms.",Tnma&ate connctions */
strvatecleanup:ine->s    !if (GetLastError()etEvent( 
                 y * n" tEvent(g    intC     ns an   apx   */ eFileW(lD    apxpeFilename) { */
strvate{
     S      R  g>ouy   */rraDWRADaem   DWORDsT_STR _c   M   */r(ns[i].dwC   C  p = 0;

 
{
  ats conIh;ileW(lif (!lp b  ct conAPXileW(lswitch
   CtrlC  p xpandStrW(gPchttpdle = NUCONTROLe HUTDOWN:te connnnnnnnn   turn FALSE;
    }
 INFO O"      R HUTDOWN salThraetLastError(ERchttpdle = NUCONTROLe TOP:te connnnnnnnnr     PT_STR Sby SC(dle = NUO_ST_NVIRING,gNO_Eritear3A*{
  e));
      if e   S    ns an      Rasynch(!Sousl
a*e && (_options[ b  ct coniULC6432,ct con(the arr,EG_SOFTWARE | APXREG_SERVICE     el    TsT_STR Sb  ,EG_SOFTWARE | APXREG_SERVICE     el    T  = SO_)  CtrlC  p,EG_SOFTWARE | APXREG_SERVICE     el    T0, &ts conIhe));#   0);
      if e   Seematwe don'tanee j>sz aitPX   nsedSt   ns conEG_SOFTWARE | A*j>szStecuhEG_SOFTWARE | A*e && (_options[
        if (dw == W b  ct con, INFINITNe));#/* NULL terrrrrrrrr      y * n" b  ct con      lpWrapper-rOR_SUastError(ERchttpdle = NUCONTROLePWSTRROG (c:te connnnnnnnnr     PT_STR Sby SC(alaunched by SC.  CurrentSby =REG_SOFTWARE | APXREG_SERVICE     efker      by SC.  Win32direC  pREG_SOFTWARE | APXREG_SERVICE     efker      by SC.  WaitHins      lpWrapper-rOR_SUastError(ER, L"  v:te connnnnnnnnb cokastErr}te{
     Consol R  g>ouy   */rraDraDWRAJAVA_  DWORDconsol M   */r(ns[i].dwC   ov = = 0;

 switch
   Ctrlov = xpandStrW(gPchttpCTRL_BRE 
 TVENT:te connnnnnnnn   turn FALSE;
    }
 INFO OConsol RCTRL+BRE 
tedwRoasalThraetLastError(ERper-rOR_SUstatic BOMDOPPPPPchttpCTRL_C TVENT:te connnnnnnnn   turn FALSE;
    }
 INFO OConsol RCTRL+CtedwRoasalThraetLastError(ERper-sT_STR Sb     = SO_)dle = NUCONTROLe TOPLastError(ERper-rOR_SUspCmdline->sPPPPchttpCTRL_C_OS  TVENT:te connnnnnnnn   turn FALSE;
    }
 INFO OConsol RCTRL+C_OS jedwRoasalThraetLastError(ERper-sT_STR Sb     = SO_)dle = NUCONTROLe TOPLastError(ERper-rOR_SUspCmdline->sPPPPchttpCTRL_ HUTDOWN TVENT:te connnnnnnnn   turn FALSE;
    }
 INFO OConsol R HUTDOWN edwRoasalThraetLastError(ERper-sT_STR Sb     = SO_)dle = NUCONTROLe HUTDOWN astError(ERper-rOR_SUspCmdline->sPPPPchttpCTRL_
  OFF TVENT:te connnnnnnnn   turn FALSE;
    }
 INFO OConsol R
  OFF edwRoasalThraetLastError(ERper-D)
!fker       */ APXCMDOPT_STR) {ptiosT_STR Sb     = SO_)dle = NUCONTROLe TOPLastError(ERper-}stError(ERper-rOR_SUspCmdline->sPPPPb cokaststErr}te r-rOR_SUstatic BO{
     Main $(WORKD exandsTon lo   DWRADaem   DWORDsT_STR Main(ns[i].d  crr =Ti].d*lpPv = 0;

 
{
  rce h0 voionsalaunched by SC.  LT_STR ov = ttttt=ndle = NUen Tu_OWN_PROW(gPate conalaunched by SC.  CurrentSby = tttt=ndle = NU__STA_NVIRINGate conalaunched by SC.  Crg>ousAcceperdt=ndle = NUCONTROLePWSTRROG (cate conalaunched by SC.  Win32direC  ptttt=n0 voionsalaunched by SC.  CheckPoi    ttttt=n0 voionsalaunched by SC.  WaitHinsW(lpWrttt=n0 voionsalaunched by SC.  LT_STR SiguratcdireC  pr=.0APXileW(l   turn FALSE;
    }
     n NIcLideeST_STR MainI..tLaststErro    if etLastue ING(fker     er->o APXCMDOPT_ST;
   en[SIZ_HUGLEN]ate conErro nsWiate conErroPSECURITYOATe IBUTES sar=.G    llACLVIastError(ERtion);
  en,taIZ_DESLEN lL"Global  "LastError(ER      lstren,taIZ_DESLEN lfker     er->oastError(ER      lstren,taIZ_DESLEN ln[1024SIGNA  PXCMDOPT_MSX   (ir=.7; i <R     entren(g i++& PXCMDOPT_STR) { /* en[i],  L' 'FEG_SOFTWARE | APXRen[i], L'_'astError(ERper-SZ) voionsTRUEper-APXRen[i], towuppr(en[i]&ate connnnnFileW(lpWragnalThread  =rrC6432,e;
 W(sa        CESS)e ee(APXLOG_MARKClean  llACLV Daem *)sa(APXileW(lpWra          }
    {    aErr =     
{
  tidastError(ERper-      }ct coniULC6432,ct con(the arr, edwRoct con, the arr, &tidgging fug functionsnctionsintCheckons aS   sM */{
        iif etLastue ING( SOO_STAOGPA( APileW(lpWra    HaRV_AUTO)  SO_TYPEOGPA ln[1024JVM( APXCMDOPT_STionsfrker lass  
spCmdline->seW(lpWra    if etLastue ING( SOO_STAO_JVM_ APXCMDOPT_STR) {ptio h torn clatt=nWideToANSI( SOO_STAO_JVM_PXCMDOPT_MSSSSSSSSS     changi/  updotions[i s clhealue && (_options[[[[[a     CharRepla;A(th torn cla, '.', '/'LastError(ERper-}stError(ERper-SZ) {    aErr = TRUEper-intPresum( c s main ue && (_options[[[[[ h torn clat=nWideToANSI(L"MaintLastErroTRUEper-e & APXCMDO[[[[ h tor
{
 u=fine SSTART (!(ate connnnnFileW(lpWraSZ) {    HaRV_AUTO)  SO_TYPEOGPA ln[1024JAVA_ APXCMDOPT_STR) {ns[i].djxxpeFile  szJHc=ne SOAVAHOMdline->seW(lpWra    !szJHFEG_SOFTWARE | APXRszJHc=n   Get}
 SoftHom E       ons * {
    r = TRUESZ) {    HaRV_AUTO) szJH ln[1024JDK_ APXCMDOPT_STR) {ptiointFCmdlN NT u*
  ODKtJfilHom  ue && (_options[[[[[szJHc=n   Get}
 SoftHom E       ons * {
    r = TRUE}stError(ERper-SZ) {    HaRV_AUTO) szJH ln[1024JRT( APXCMDOPT_STT_STptiointFCmdlN NT u*
  OREtJfilHom  ue && (_options[[[[[szJHc=n   Get}
 SoftHom E       atic )
        TRUE}stError(ERper-    szJHFAPXCMDOPT_STT_STptiojxxpeaWO    AllocE       (     entrszJHFA+ 16)te  izeof(;
  ( ));
      if egistaRV_A
  jx  szJH ));
      if egistaRV_Alstrjx  n[1024JBIN astError(ERper-per-    ! SOO_STARTCL& PXCMDOPT_STT_STptioptiointU   OAVA_HOMd/bin as"
   st_jni_{
                     ns[i].dszJPxpeaWO    AllocE       (     entrszJHFA+ 8)te  izeof(;
  ( ));
      if egistgistaRV_A
  szJP  szJH ));
      if egistgistaRV_AlstrszJP  n[1024PBIN astError(ERper-per----- SOO_STARTCL   szJPastError(ERper-per-}stError(ERper-}stError(ERper-SZ) {    aErr = TRUEper-   turn FALSE;
    }
 TDOUTP"Une
 **p;find JfileRuntT_I  if (!SO_EN.tLastErroionsTRUEper-go>szcleanupate connnnnper-}stError(ERper-les andlass  
spCmdline->seW(lpWra   S assPT_ST nowR  g>ain;*
  fulo _jni_>sz*
  es a.exaa*e && (_options[SSOO_STAOPPAT
sjxging fug functionsnctionsintCheckons aS opM */{
        iif etLastue ING( SOO_STOGPA( APileW(lpWra    HaRV_AUTO)  SO_TSTOGPA ln[1024JVM( APXCMDOPT_STionsfrker  object+
spCmdline->seW(lpWra    if etLastue ING( SOO_STO_JVM_ APXCMDOPT_STR) {ptio h tosn clat=nWideToANSI( SOO_STO_JVM_astErroionsTRUEper-a     CharRepla;A(th tosn cla, '.', '/'LastError(ERper-}stError(ERper-SZ) {    aErr = TRUEper-intD L"  v lndeMain ue && (_options[[[[[ h tosn clat=nWideToANSI(L"MaintLastErroTRUEper-e & APXCMDO[[[[ h tos
{
 u=fine SSTif (!(ate connnnnFileW(lpWraSZ) {    HaRV_AUTO)  SO_TSTOGPA ln[1024JAVA_ APXCMDOPT_STR) {ns[i].djxxpeFile  szJHc=ne SOAVAHOMdline->seW(lpWra    !szJHFEG_SOFTWARE | APXRszJHc=n   Get}
 SoftHom E       ons * {
    r = TRUESZ) {    HaRV_AUTO) szJH ln[1024JDK_ APXCMDOPT_STR) {ptiointFCmdlN NT u*
  ODKtJfilHom  ue && (_options[APXRszJHc=n   Get}
 SoftHom E       ons * {
    r = TRUE}stError(ERper-SZ) {    HaRV_AUTO) szJH ln[1024JRT( APXCMDOPT_STT_STptiointFCmdlN NT u*
  OREtJfilHom  ue && (_options[[[[[szJHc=n   Get}
 SoftHom E       atic )
        TRUE}stError(ERper-    szJHFAPXCMDOPT_STT_STptiojxxpeaWO    AllocE       (     entrszJHFA+ 16)te  izeof(;
  ( ));
      if egistaRV_A
  jx  szJH ));
      if egistaRV_Alstrjx  n[1024JBIN astError(ERper-per-    ! SOO_STOPCL& PXCMDOPT_STT_STptioptions[i].dszJPxpeaWO    AllocE       (     entrszJHFA+ 8)te  izeof(;
  ( ));
      if egistgistaRV_A
  szJP  szJH ));
      if egistgistaRV_AlstrszJP  n[1024PBIN astError(ERper-per-----intU   OAVA_HOMd/bin as"
 opt_jni_{
                      SOO_STOPCL   szJPastError(ERper-per-}stError(ERper-}stError(ERper-SZ) {    aErr = TRUEper-   turn FALSE;
    }
 TDOUTP"Une
 **p;find JfileRuntT_I  if (!SO_EN.tLastErroionsTRUEper-go>szcleanupate connnnnper-}stError(ERper-les and object+
spCmdline->seW(lpWra   S   PT_ST nowR  g>ain;*
  fulo _jni_>sz*
  es a.exaa*e && (_options[SSOO_STOPPAT
sjxging fug functionsnctionsintFind**
   TR  _jni{
        ifrker  object+|| frker lass  FILE_NOT_FOUND)
if etLastue ING( SOJVM( APXCMDOPT_STions 0) aRV_AUTW( SOJVMlsn[1024];
 
        el    This h to jvm dlc=ne SO_Jate connnnnFileW(lpWraD)
if etLastue ING( SOO_JVM_JAV 
        el     LPCWSTR  _jnit=nWideToANSI( SOO_JVM_JAV ;ileW(lpWraD)
if etLastue ING( SO_TYPEOETHOD 
        el   Shutdorn meth tt=nWideToANSI( SOO_STAOETHOD ;ileW(lpWraD)
if etLastue ING( SO_TSTOETHOD 
        el   Shutdosn meth tt=nWideToANSI( SOO_STOETHOD ;ileW(lpWrath to jvm optio  tt=nMzWideToANSI( SOO_JOAYNAMS&ate connctionsrintfker       */ APXCMDOPT_STintR     apx"      RC g>ouy   */rteFileW(lpWra_launched by SCM   */t=nR     apPT_STR o    y * nrW(fker     er->,EG_SOFTWARE | APXREG_SERVICE     el    ThisssssssssssssssssssssssT_STR _c   M   */r {
    r =S 0) if (GetLastError()alaunched by SCM   */& APXCMDOPT_STions return FALSE;
    }
 TDOUTP"Fail(de>szr     apx"      RC g>ouyX   %
stEG_SOFTWARE | APXREG_SERVIfker     er->oastError(ERRRRRgo>szcleanupate connnnnFileW(lpWraintAllocy = consol  If thastedwRos geos O_LOGRO(deue && (_opti    !AttachConsol (ATTACH_if ENT_PROW(gP& &&EG_SOFTWARE | AGy = apxCreat)    Write((GetLastError( APXCMDOPT_STionsHWND hcastError(ERRRRRAllocConsol (LastError(ERper-D)
(hcr=.G  Consol Window()_HIDEthe  EG_SOFTWARE | APXRShowWindow(hc, SW_HIDc )
        nctionsnctions *    PT_STR Sby SC(dle = NUO_STA_NVIRING,gNO_Eritear3
  e));
  D)
(rce hsT_STR Sb  s  )           aErr =    S      RisR bart d eFileW(lpWraRO    PT_STR Sby SC(dle = NURUNNING,gNO_Eritearrgging fuuuuuname provided");
          n NWaitLPAPX  l     _j>szStecuhI..tLastErroionsint    consol     */rt>szcaptdlN CTRLtedwRos eFileW(lpWraS  Consol o    y * nr((PError(R_ROUTINE)consol M   */r  atic )
ing fuuuuunam y * nWait)gtEvent, INFINITN,ions * {
    r = name provided");
          n NW    _jfxecuhed.tLastErronctions_SYSAPXCMDOPT_ST   turn FALSE;
    }
 TDOUTP"ST_STR Sb  s-rOR_SU d %dt src     break;go>szcleanupate connctionsrint  alEvent   = (APXCstErroionsintEnsdlN thast  object+ns con ex hs beX  e us eFileW(lpWraname provided");
          n NWaitLPAPX  l alEvent   = tLastErroions *    PT_STR Sby SC(dle = NUO_ST_NVIRING,gNO_EritearONE_MINUT* {
    r = 
        if (dw == WAIalEvent   = arONE_MINUT* {
    r =    turn FALSE;
    }
     n N alEvent   = NsalThraetLastError(ER      y * n"  alEvent   = (APXstErroionsintTs)s OOL  c (def>sz aitPX     upns consetoTemitEG_SOFTWAREeFileW(lpWraname provided");
          n NWaitLPAP1 mxeds *X     upns consetoTemittLastErroions *    PT_STR Sby SC(dle = NUO_ST_NVIRING,gNO_EritearONE_MINUT* {
    r =    PeRV_oyJvm(ONE_MINUT* {
    nctions_SYSAPXCMDOPT_ST/
 
= cr->fse utns[iagel  object+edwRoEG_SOFTWAREe Probe
y bec (defmaint) rOR_SU d ns[iagelensdl    a upns consEG_SOFTWAREe dow()fxecuhedEG_SOFTWAREeFileW(lpWraname provided");
          n NWaitLPAPX     upns consetoTemittLastErroions   PeRV_oyJvm(INFINITNe));Erroions *    PT_STR Sby SC(dle = NUO_ST_NVIRING,gNO_Eritearugging functions   turn FALSE;
    }
     n NJ_Je eRV_oyed.tLastErro *    PT_STR Sby SCS   p d(   GetVmdireC  p()&;
 stErro *R_SUastcleanup:ine->sintC eanupEeFileW(l *    PT_STR Sby SCS   p d(rc     bregdirevale hrc;stErro *R_SUast{
  printRun ns an      Rin ns adebugD  */{
 line)docmdDebug
      E hRegistry;
    int i = 0;

 fker       */
static BOMDOPfker     er->f=R
            apxLogWrite;ctions   turn FALSE;
    }
 INFO ODebuggLPAP->sz"start",I..t lfker     er->oastErrosT_STR Main(0e the  PXCMDOP   turn FALSE;
    }
 INFO ODebugsn      Rfxecuhedons[i]ex hat  p %dt sgdirevalLastErroSAFE_C_OS  Error()e idX: SxLogWr(APXLOG_ */
stgdirevale     ? atic :static BO{
  line)docmdRun
      E hRegistry;
    int i = 0;

 apper,vastErroSle = NUTABLE_ENTRYW di _jnch_s:\n"[], PXCMDOPT_ST{E                     APXRnE hSle = NUMAIN_FUNCYNAMW)sT_STR Main },XCMDOPT_ST{EFile  File nctionsn BOMDOPfker       */
spCmdline->sfker     er->f=R
            apxLogWrite;ctions   turn FALSE;
    }
 INFO ORunnLPAP->sz"Start",I..t lfker     er->oastErropper b  sPT_STR o   Di _jnchnrW(di _jnch_s:\n"( APXCMDOPT_ST   turn FALSE;
    }
 INFO ORun n      Rfxecuhed.tLastErroLOG_ v 
spCmdline->s{
        _PXCMDOPT_ST   turn FALSE;
    }
 TDOUTP"Sb  sPT_STR o   Di _jnchnrPX   ->sz"fail(dstEG_SOFTWARE | APXREG_S
            apxLogWrite(APXErroLOG_ v 
sCESS);
    hRegist AFE_C_OS  Error()e idX: SxLogWr(APXLOG_ */
strvate{
  P *lpWrconstschar *gSzP_LO[], PXCMDOP"stEG_SOF"pars        else ifd        stEG_SOF"
{rcon  APXHANDLstEG_SOF"run n      Ras consol  apxLogWritestEG_SOF"run n      stEG_SOF"
   stn      stEG_SOF"
 optn      stEG_SOF"umetersn      R
{
    instEG_SOF"r L"  upn      stEG_SOF"dL"   an      stEG_SOFFilete{;
 stDaem __cdeclfmaint nsWd  crrchar **lpPv = 0;

 U   /rve h0;il;

  hRegistry;
    int i;ststErro    d  c > 1 APXCMDOPT_ST
{
  sse h0 voionsTRUE    strncmp d  v[1], "//PPt l4)           aErr = TRUEintxLogy sleep rodsTE *, L"  vNT; *p;1 mxeds *ue && (_options[    d  v[1][4] {
   v[1][5] {
   v[1][6]& PXCMDOPT_STT_STptioiionusxpeatoi d  v[1] + 6 astError(ERper-per-    usx>   EG_SOFTWARE | APXREG_Ssat=n(ns[i])usastError(ERper-}stError(ERper-Sleep(ROT{{
  e));
      if edireP_LOGRO( e));
      if erOR_SUastError(ERFileW(lpWraSZ) {    RV_AUT d  v[1], "p (de")           aErr = TRUEintxLogy sleep rodsTE *, L"  vNT; *p;1 mxeds *ue && (_options[    d  c > 2& PXCMDOPT_STT_STptioiionusxpeatoi d  v[2] astError(ERper-per-    usx>   EG_SOFTWARE | APXREG_Ssat=n(ns[i])usastError(ERper-}stError(ERFileW(lpWraD)
ss& PXCMDOPT_STT_STSleep(ROT{{
  e));
      if edireP_LOGRO( e));
      if erOR_SUastError(ERFileW(lnctions   xLogWrManager, ititliz Ee));
  intC6432, *
  main      eFileW(lD     peaWO    C6432,(the arr&;
 stErrointPLrs **
        else ifeFileW(lD)
(    int ixpe_WOW int iPLrs          m optio         eo   altcmds )    the  _PXCMDOPT_ST   turn FALSE;
    }
 TDOUTP"Inv gRar      else ifd        s(APXErroLOG_ v 
s1ate connnnngo>szcleanupate connctions_WOW int iL
{EnvVLrsE    int i astErropper
          dwCmd, dex < 6 APileW(lpWra    Ha
{
    APXHANDLE    int i  &&EG_SOFTWARE | 
          dwCmd, dex < 5 APXCMDOPT_STions return FALSE;
    }
 TDOUTP"L
{rcon  APXHANDL"fail(ds      lpWrapper-rve h2     lpWrapper-go>szcleanupate connnnnFileW(l}PXileW(l   turOpen       aErr)
_JAV,  SO)
_REFIX,  SO)
ROTATNe));Erro   turLedwlS  P(the ar SO)
LEVE  PXCMDOP   turn FALSE;
    }
     n Nfwprtio Daerti O_LOrun loge cititliz ds      lppper SO)
ROTATNeileW(lpWraname provided");
          n Ne p OOL  roby = eachs%des conds.",T SO)
ROTATNe));ctions   turn FALSE;
    }
 INFO Ofwprtio Daerti O_LOrun (%ss%d-bit)R bart dstEG_SOFTWARE | APXRPRG_VERSNAM,RPRG_BITSe));ctionsAplZeroMertry &D  dwrap,  izeof(E;UO_DWRAP( ));
  g" artPjniker     er->oasttionsAplZeroMertry &D  dwrap,  izeof(E;UO_DWRAP( ));
  g" artPjniker     er->oasttionsAplZeroMertry &D  dwrap,  izeof(E;UO_DWRAP( ));
 RPRG_VERSNAM APXCMDOPT_STionsfrker ionschar pids[32]     lpWrapper-g idX: SxLogWriUl}PXileW(l   turOpen t4OPT_STTCMDOPT_ST   turn FA&D  dwrap,  izeof(E;UO_DWRAPOa;
    }
     n N   ru     _jfxecuhed.tLastErroTRUEe & APXCMDOwait_to_di/
spCmdline->s{
cleanup:ine I,cleanup:ine I,cleanup:ine I,cleanup:ine I,cleanup:ine I,cleanup:ine dle = NUCONTRcleanuizeof(E;    er->Dsi(daSZ)R dle = NUCON6?if G]6MlearBOMDOPfker       */
spCmdline->sfker     er->f=R
            apxLogWrite;ctions   turn FALSE;
    }
 INFO ORunnLPAP->sz"Start",I..t lfker     er->oastErropper b  sPT_STR o   Di _jnchnrW(di _jnch_iPLrs          m optio         eo   altcEiPLait)gtEvent, tT_INT  satic )    }
 TDOUTP"ST_ING( Surn MO_Eriteartions_SYSAPXCMDOPT_ST   toPXHr-    Lns_ritLLPAPX  l     _j>sp="//PR e }
 TDOUTP"Inv gRar      else ifd        s(APXErroLOG_ v iRING,gNO_Eritear3A*{
  e));
      if eyli_INT  satic ) UO_DWRAPOa;
 NO_Eriteara;
 NO_Eriteara;
 NO_Eriteara;
 NO_Eriteara;
 NO_Eriteara;
 NO_E
 NO     RV_PXEe       ra;OPfker     er->f=R
    ar euroTRUEe & APXCMDOwait_to_di/
spCmdline->s{
cleanup:ine I,cleanup:ine I,cleanup:ine Ip eachs%des conds."WeSeanuCmdline->s{
cleanup:ine I,cleanup:ineitsPf edireP_LOG eachs%des conds."|aT Daerti O_LOruachs%dXCMDOSOFTWARE | APXRszJHc=n   Ger-   turn FALSE;
    }
     n NJfileh t 
   D     _Mons returss& PXCMDOPT_STT_STSleeSE;nuizeof(E;    er->Dsi(daST_Sreturss& PXCMDOPT_STT_STSleeSE;nuizeof(E;    er->Dsi(daST_Sreturss& PT_Sreturss& PT_Sdper-}stEr/PC      ->Dsi(daer-or(ERFileW(l ->Dsi(daer-orlm3AUTsileW(lpeSeanuCmdline->s{
cleanup:ine I,cleanup:ineitsPf edireP& PXCMDOPT_STT_STSleetJfilHom  ue && (_option
ROTATNe));ctio con    p
   d>l I,cleanup:ine dle = NUCONTRcleanuizeof(E;    er->Dsi(daSZ)R dle =A[If=RRPRG_VERanup:ine dlileasaSZ)Rtion
ROTATNe));cccccccc Sb (NT  sati6   n ROT
     n    geturss& PT_Sdper-}stEr/PC      ->Dsi(           G,gNO_ss& PXCMDOP   }
  ssssssssu,gNO_ss& PXCMDOf WAIalEvenHom N onnnnnFileW(lpo"Cu[CMDOf WAIalEvenHomDOf WAIalo"Cuw+bIdaer-oMUiIi(] + 6 a _nCMD =A[Ifdle = rro G,gNO_ss& PXARE | APXREG_S
            apxLogWrite(APXErroLOG_ v 
sCESS);
    hRegist A->fse utns[iageEOG_ v 
sCESS);
 vCmdline->seW(lpWra  saese   sati6Cotions   xLogWrManagC i(] + 6 a _nCMD EoamastErropper b  sPT_STR o   DwU_xntrszJHFA+ 8APXEuM3roptv 
sCESS);
 vCmdline->seW* E hRe- _PXCMDOPT_ST   n N)0ROG (cm0s  DwU_xnPXCMDOPTPT_ST   n N)0ROG (cm0s  DwU_xnPXCMDOPTPT_ST   n z  elm0s  DoINFO ODebugsn     sCer b  sPT_ST Ip ealEvenHom N onnnnnFileW(lpoeanup:i  nweanupate connileW(l& PXaniiiiiiiiiiimy(N0ROG (cm0s  DwU_xnPXCMDOPTenHy(N0ROCMDCMDOPTenHy(OCMDePXCMDO,0ROFF(MDOi]ex hat  pr EMDCMDOPTenHy(OCMDePXCMDO,0RO)O[], PXCMSOO_JOAYNAMS&ate connctionsrintfker     eOO_ = ICmdlapxLogWrite(ALEN lL"G;
 vCa{   er b  sPT_STu 
 INFO sPTPXCMDO,e = NUMAIN_F/     idX: SxLogWr, pids, (hti